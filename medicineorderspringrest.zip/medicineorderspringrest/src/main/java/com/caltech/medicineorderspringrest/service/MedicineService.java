package com.caltech.medicineorderspringrest.service;

import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caltech.medicineorderspringrest.pogo.Medicine;
import com.caltech.medicineorderspringrest.repo.MedicineRepository;

@Service
public class MedicineService {
	
	Logger log=Logger.getAnonymousLogger();
	
	@Autowired
	MedicineRepository service;
	
	public String insert(Medicine medicine) {
		Medicine m=service.save(medicine);
		if (m==null) {
			return "Error in adding the Medicine";
		} else {
			return "Medicine added successfully";
		}
		
	}
	
	public List<Medicine> getAllMedicinies(){
		return service.findAll();
	}
	
	public Medicine getMedicineById(Integer id) {
		return service.findById(id).orElse(null);
	}
	
	public List<Medicine> getMedicinesByName(String name){
		return service.getMedicinesByName(name);
	}
	
	public String deleteMedicineById(Integer id) {
		service.deleteById(id);
		return "Medicine deleted successfully";
	}
	

	public String updateMedicine(Medicine medicine) {
		
		Medicine m1 = service.findById(medicine.getId()).get();
		if (m1 != null) {
		    m1.setAddress(medicine.getAddress());
		    m1.setPhone(medicine.getPhone());
		    m1.setName(medicine.getName());
		    
		}
		
		Medicine m=service.save(m1);
		if (m==null) {
			return "Error in adding the Medicine";
		} else {
			return "Medicine added successfully";
		}
	}
	

}
